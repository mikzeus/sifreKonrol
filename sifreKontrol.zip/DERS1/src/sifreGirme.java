import java.util.Scanner;

public class sifreGirme {
    public static void main(String[] args) {

        String userName, password;

        Scanner input = new Scanner(System.in);

        System.out.print("lütfen Kullanıcı Adını giriniz:");
        userName = input.nextLine();

        System.out.println("Lütfen Şifrenizi giriniz:");
        password = input.nextLine();

        if (userName.equals("mune") && password.equals("m123")) {

            System.out.println("sisteme giriş yaptınız:");

        } else {

            System.out.println("kullanıcı adı veya şifrenizi yanlış girdiniz:");

            while (true) {
                System.out.println("Şifrenizi sıfırlamak istermisiniz:");


                String cevap;
                cevap = input.nextLine();

                if (cevap.equalsIgnoreCase("e")) {

                    System.out.println("lütfen yeni bir kullanıcı adı giriniz:");
                    userName = input.nextLine();
                    System.out.println("lütfen yeni bir şifre giriniz:");
                    password = input.nextLine();


                    if (userName.equals("mune") && password.equals("m123")) {
                        System.out.println("Şifre oluşturulamadı, lütfen başka şifre giriniz");

                    } else {
                        System.out.println("başarılı");
                        break;
                    }

                } else if (cevap.equalsIgnoreCase("h")) {
                    System.out.println("işlem iptal edildi");


                } else {
                    System.out.println("lütfen geçerli bir cevap giriniz!:");

                }
            }
        }

    }
}








