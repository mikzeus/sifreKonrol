import java.util.Scanner;

public class frt {
    public static void main(String[] args) {
        String userName, password;

        Scanner input = new Scanner(System.in);

        System.out.print("lütfen Kullanıcı Adını giriniz:");
        userName = input.nextLine();

        System.out.println("Lütfen Şifrenizi giriniz:");
        password = input.nextLine();

        if (userName.equals("mune") && password.equals("m123")) {

            System.out.println("sisteme giriş yaptınız:");
        } else {
            System.out.println("kullanıcı adı veya şifrenizi yanlış girdiniz:");

            System.out.println("Şifrenizi sıfırlamak ister misiniz?(e/h):");

            String cevap;
            cevap = input.nextLine();

            if (cevap.equalsIgnoreCase("e")) {

                System.out.println("lütfen yeni bir şifre/kullanıcı adı giriniz:");

                System.out.println("lütfen kullanıcı adı giriniz:");
                userName = input.nextLine();

                System.out.println("Lütfen şifrenizi giriniz");
                password = input.nextLine();

                if (password.equals("m123")) {
                    System.out.println("Şifre oluşturulamadı, lütfen eski şifrenizden farklı bir şifre giriniz");
                } else {
                    System.out.println("yeni şifre başarıyla oluşturulmuştur");

                }
            } else if (cevap.equalsIgnoreCase("h")) {
                System.out.println("Yeni şifre oluşturma işlemi reddedilmiştir, iyi günler dileriz.");

            } else {
                System.out.println("Lütfen geçerli bir cevap giriniz: (e: evet, h: hayır)");
            }
        }
    }
}



